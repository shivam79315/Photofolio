import React, { useState, useEffect } from "react";
import styles from "./Images.module.css";
import { useParams } from "react-router-dom";
import { collection, getDocs, doc } from 'firebase/firestore';
import { db } from "../../firebaseInit";
import imageSvg from '../../assets/logo/image-svg.svg';

const ImagesList = () => {

  const { albumId } = useParams();
  const [allImages, setAllImages] = useState([]);
  
  useEffect(() => {
    const fetchImages = async () => {
      try {
        const albumRef = doc(db, "gallery", albumId);
        const imagesCollectionRef = collection(albumRef, "Images");

        const imagesSnapshot = await getDocs(imagesCollectionRef);

        const imagesList = imagesSnapshot.docs.flatMap((doc) => 
          Object.entries(doc.data())
            .filter(([key]) => key.startsWith("img"))
            .map(([, value]) => ({ id: doc.id, image: value }))
        );        

        console.log(imagesList);
        
        setAllImages(imagesList);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    fetchImages();
  }, [albumId]);

  return (
    <div className={styles.listContainer}>
      {allImages.length > 0 ? (
        allImages.map((url, index) => (
          <div key={index} className={styles.image}>
            <img src={url || imageSvg} alt={`Image ${index + 1}`} />
            <button className={styles.editBtn}>Edit</button>
          </div>
        ))
      ) : (
        <span>No images available</span>
      )}
    </div>
  );
};

export default ImagesList;
